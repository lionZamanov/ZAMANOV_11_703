create function add_year_to_name()
  returns trigger
language plpgsql
as $$
DECLARE
BEGIN
  INSERT INTO movie VALUES (NEW.name, 'ROFL', 1999, 'Russia', 99999);
END;
$$;

alter function add_year_to_name()
  owner to ex3;

