create function date_part(text, reltime)
  returns double precision
stable
strict
cost 1
language sql
as $$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$$;

comment on function date_part(text, reltime)
is 'extract field from reltime';

alter function date_part(text, reltime)
  owner to postgres;

